package com.spring.ProgettoDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoDemoApplication.class, args);
	}

}
